Web und Multimedia Engineering - Aufgabe 1 

Team 3 
Verona Kolpe (4609197)
Felicitas Schmelz (4643874)
