Aufgabe 2
Team 3 
Verona Kolpe & Felicitas Schmelz 
